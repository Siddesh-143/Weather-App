/**
 * WeatherVista – script.js
 * Senior Full Stack & UI/UX Developer Implementation
 * Responsive, Glassmorphic Weather Dashboard
 */

// ─── CONFIGURATION & STATE ───
// REPLACE 'YOUR_API_KEY' WITH A VALID OPENWEATHERMAP API KEY
const API_KEY = 'YOUR_API_KEY';

const STATE = {
  units: localStorage.getItem('wv_units') || 'metric', // 'metric' (°C) or 'imperial' (°F)
  theme: localStorage.getItem('wv_theme') || 'dark',
  currentCity: '',
  lat: null,
  lon: null,
  weather: null,   // Current weather cached response
  forecast: null,  // 5-Day forecast cached response
  aqi: null,       // Air Quality cached response
  history: JSON.parse(localStorage.getItem('wv_history')) || [],
  favorites: JSON.parse(localStorage.getItem('wv_favorites')) || [],
  isDemo: false
};

// Major Cities for Autocomplete Fallback / Demo Suggestions
const POPULAR_CITIES = [
  { name: 'Mumbai', country: 'IN', lat: 19.0760, lon: 72.8777 },
  { name: 'New York', country: 'US', lat: 40.7128, lon: -74.0060 },
  { name: 'London', country: 'GB', lat: 51.5074, lon: -0.1278 },
  { name: 'Tokyo', country: 'JP', lat: 35.6762, lon: 139.6503 },
  { name: 'Paris', country: 'FR', lat: 48.8566, lon: 2.3522 },
  { name: 'Sydney', country: 'AU', lat: -33.8688, lon: 151.2093 },
  { name: 'Dubai', country: 'AE', lat: 25.2048, lon: 55.2708 },
  { name: 'Singapore', country: 'SG', lat: 1.3521, lon: 103.8198 },
  { name: 'Berlin', country: 'DE', lat: 52.5200, lon: 13.4050 },
  { name: 'Toronto', country: 'CA', lat: 43.6532, lon: -79.3832 }
];

// Check if running in Demo Mode
STATE.isDemo = (!API_KEY || API_KEY === 'YOUR_API_KEY' || API_KEY.trim() === '');

// ─── DOM SELECTORS ───
const DOM = {
  themeBtn: document.getElementById('btn-theme'),
  iconMoon: document.getElementById('icon-moon'),
  iconSun: document.getElementById('icon-sun'),
  btnCelsius: document.getElementById('btn-celsius'),
  btnFahrenheit: document.getElementById('btn-fahrenheit'),
  btnVoice: document.getElementById('btn-voice'),
  btnRefresh: document.getElementById('btn-refresh'),
  
  searchInput: document.getElementById('search-input'),
  btnClearSearch: document.getElementById('btn-clear'),
  autocompleteList: document.getElementById('autocomplete-list'),
  btnSearch: document.getElementById('btn-search'),
  btnLocation: document.getElementById('btn-location'),
  btnEmptyLocation: document.getElementById('btn-empty-location'),
  
  historyPanel: document.getElementById('history-panel'),
  btnClearHistory: document.getElementById('btn-clear-history'),
  historyList: document.getElementById('history-list'),
  
  emptyState: document.getElementById('empty-state'),
  errorState: document.getElementById('error-state'),
  errorTitle: document.getElementById('error-title'),
  errorMsg: document.getElementById('error-msg'),
  btnRetry: document.getElementById('btn-retry'),
  
  dashboard: document.getElementById('dashboard'),
  loadingOverlay: document.getElementById('loading-overlay'),
  toastContainer: document.getElementById('toast-container'),
  
  // Weather Info
  cityName: document.getElementById('city-name'),
  countryName: document.getElementById('country-name'),
  datetime: document.getElementById('datetime'),
  btnFav: document.getElementById('btn-fav'),
  mainIcon: document.getElementById('main-icon'),
  currentTemp: document.getElementById('current-temp'),
  tempUnitSym: document.getElementById('temp-unit-sym'),
  weatherDesc: document.getElementById('weather-desc'),
  feelsLike: document.getElementById('feels-like'),
  
  // Stats
  humidity: document.getElementById('s-humidity'),
  wind: document.getElementById('s-wind'),
  windDir: document.getElementById('s-wind-dir'),
  pressure: document.getElementById('s-pressure'),
  visibility: document.getElementById('s-visibility'),
  uv: document.getElementById('s-uv'),
  uvBadge: document.getElementById('s-uv-badge'),
  aqi: document.getElementById('s-aqi'),
  aqiBadge: document.getElementById('s-aqi-badge'),
  sunrise: document.getElementById('s-sunrise'),
  sunset: document.getElementById('s-sunset'),
  
  // Lists & Extra sections
  hourlyList: document.getElementById('hourly-list'),
  forecastList: document.getElementById('forecast-list'),
  aqiCanvas: document.getElementById('aqi-canvas'),
  aqiBig: document.getElementById('aqi-big'),
  aqiLabel: document.getElementById('aqi-label'),
  pollutantGrid: document.getElementById('pollutant-grid'),
  alertsCard: document.getElementById('alerts-card'),
  alertsList: document.getElementById('alerts-list'),
  
  favCount: document.getElementById('fav-count'),
  favList: document.getElementById('fav-list'),
  
  btnShare: document.getElementById('btn-share'),
  btnPdf: document.getElementById('btn-pdf'),
  footerYear: document.getElementById('footer-year')
};

// ─── INITIALIZATION ───
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initParticles();
  setupEventListeners();
  updateFavoritesUI();
  updateHistoryUI();
  
  DOM.footerYear.textContent = new Date().getFullYear();
  
  if (STATE.isDemo) {
    showToast('Running in demo mode (Mock Data). Add your OpenWeatherMap API key in script.js for live data.', 'info');
  }
});

// ─── THEME & STYLES ───
function initTheme() {
  document.documentElement.setAttribute('data-theme', STATE.theme);
  if (STATE.theme === 'light') {
    DOM.iconMoon.classList.add('hidden');
    DOM.iconSun.classList.remove('hidden');
  } else {
    DOM.iconMoon.classList.remove('hidden');
    DOM.iconSun.classList.add('hidden');
  }
}

function toggleTheme() {
  STATE.theme = STATE.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('wv_theme', STATE.theme);
  initTheme();
}

// ─── PARTICLE SYSTEM (Canvas weather animation) ───
let particleCanvas, ctx, animationFrameId;
let particles = [];
let weatherCondition = 'default'; // 'sunny', 'rain', 'snow', 'clouds', 'thunder', 'night', 'default'

function initParticles() {
  particleCanvas = document.getElementById('particles-canvas');
  ctx = particleCanvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  startParticleAnimation();
}

function resizeCanvas() {
  particleCanvas.width = window.innerWidth;
  particleCanvas.height = window.innerHeight;
}

function setWeatherParticles(condition) {
  weatherCondition = condition.toLowerCase();
  particles = [];
  const count = weatherCondition === 'rain' ? 120 : (weatherCondition === 'snow' ? 80 : 40);
  
  for (let i = 0; i < count; i++) {
    particles.push(createParticle(true));
  }
  
  // Set theme background class
  const bg = document.getElementById('animated-bg');
  bg.className = 'animated-bg'; // reset
  if (weatherCondition === 'sunny') bg.classList.add('bg-sunny');
  else if (weatherCondition === 'rain') bg.classList.add('bg-rain');
  else if (weatherCondition === 'snow') bg.classList.add('bg-snow');
  else if (weatherCondition === 'clouds') bg.classList.add('bg-clouds');
  else if (weatherCondition === 'thunder') bg.classList.add('bg-thunder');
  else if (weatherCondition === 'night') bg.classList.add('bg-night');
  else if (weatherCondition === 'mist' || weatherCondition === 'fog') bg.classList.add('bg-mist');
}

function createParticle(randomY = false) {
  const w = particleCanvas.width;
  const h = particleCanvas.height;
  
  let p = {
    x: Math.random() * w,
    y: randomY ? Math.random() * h : -10,
    size: 0,
    speedX: 0,
    speedY: 0,
    opacity: Math.random() * 0.5 + 0.2,
    color: '#fff'
  };

  if (weatherCondition === 'rain') {
    p.size = Math.random() * 1.5 + 1;
    p.speedY = Math.random() * 8 + 6;
    p.speedX = -Math.random() * 1.5 - 0.5;
    p.color = 'rgba(174, 219, 255, 0.6)';
  } else if (weatherCondition === 'snow') {
    p.size = Math.random() * 3 + 1.5;
    p.speedY = Math.random() * 1 + 0.8;
    p.speedX = Math.random() * 1 - 0.5;
    p.color = 'rgba(255, 255, 255, 0.8)';
  } else if (weatherCondition === 'sunny') {
    p.size = Math.random() * 4 + 2;
    p.speedY = -Math.random() * 0.4 - 0.1;
    p.speedX = Math.random() * 0.4 - 0.2;
    p.color = 'rgba(255, 223, 100, 0.4)';
  } else if (weatherCondition === 'clouds' || weatherCondition === 'mist' || weatherCondition === 'fog') {
    p.size = Math.random() * 40 + 20;
    p.speedY = Math.random() * 0.05 - 0.025;
    p.speedX = Math.random() * 0.15 + 0.05;
    p.color = STATE.theme === 'dark' ? 'rgba(255, 255, 255, 0.03)' : 'rgba(100, 100, 150, 0.04)';
  } else if (weatherCondition === 'night') {
    p.size = Math.random() * 1.5 + 0.5;
    p.speedY = 0;
    p.speedX = 0;
    p.opacity = Math.random();
    p.color = '#fff';
  } else {
    // Default ambient particles
    p.size = Math.random() * 3 + 1;
    p.speedY = -Math.random() * 0.5 - 0.2;
    p.speedX = Math.random() * 0.6 - 0.3;
    p.color = STATE.theme === 'dark' ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.05)';
  }
  
  return p;
}

function startParticleAnimation() {
  function animate() {
    ctx.clearRect(0, 0, particleCanvas.width, particleCanvas.height);
    
    // Draw thunder flashes
    if (weatherCondition === 'thunder' && Math.random() > 0.985) {
      ctx.fillStyle = STATE.theme === 'dark' ? 'rgba(255, 255, 255, 0.15)' : 'rgba(255, 255, 255, 0.4)';
      ctx.fillRect(0, 0, particleCanvas.width, particleCanvas.height);
    }
    
    for (let i = 0; i < particles.length; i++) {
      let p = particles[i];
      ctx.beginPath();
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.opacity;
      
      if (weatherCondition === 'rain') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = p.size;
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.speedX * 2, p.y + p.speedY * 2);
        ctx.stroke();
      } else if (weatherCondition === 'night') {
        // Twinkling stars
        p.opacity += (Math.random() * 0.1 - 0.05);
        if (p.opacity < 0) p.opacity = 0;
        if (p.opacity > 1) p.opacity = 1;
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      
      // Update position
      p.x += p.speedX;
      p.y += p.speedY;
      
      // Reset if out of bounds
      const outOfBounds = 
        p.y > particleCanvas.height + 20 || 
        p.y < -30 || 
        p.x > particleCanvas.width + 20 || 
        p.x < -40;
        
      if (outOfBounds) {
        particles[i] = createParticle(false);
      }
    }
    
    ctx.globalAlpha = 1.0; // Reset
    animationFrameId = requestAnimationFrame(animate);
  }
  animate();
}

// ─── TOAST NOTIFICATION ───
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  DOM.toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ─── EVENT LISTENERS SETUP ───
function setupEventListeners() {
  // Theme Toggle
  DOM.themeBtn.addEventListener('click', toggleTheme);
  
  // Units Toggle
  DOM.btnCelsius.addEventListener('click', () => setUnits('metric'));
  DOM.btnFahrenheit.addEventListener('click', () => setUnits('imperial'));
  
  // Search Events
  DOM.btnSearch.addEventListener('click', () => performSearch());
  DOM.searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') performSearch();
  });
  DOM.searchInput.addEventListener('input', handleSearchInput);
  DOM.btnClearSearch.addEventListener('click', clearSearchInput);
  
  // Close suggestions or history when clicking outside
  document.addEventListener('click', (e) => {
    if (!DOM.searchInput.contains(e.target) && !DOM.autocompleteList.contains(e.target)) {
      DOM.autocompleteList.classList.add('hidden');
    }
    if (!DOM.searchInput.contains(e.target) && !DOM.historyPanel.contains(e.target)) {
      DOM.historyPanel.classList.add('hidden');
    }
  });
  
  DOM.searchInput.addEventListener('focus', () => {
    if (DOM.searchInput.value.trim() === '' && STATE.history.length > 0) {
      DOM.historyPanel.classList.remove('hidden');
    }
  });

  // Location APIs
  DOM.btnLocation.addEventListener('click', detectUserLocation);
  DOM.btnEmptyLocation.addEventListener('click', detectUserLocation);
  DOM.btnRefresh.addEventListener('click', refreshWeather);
  
  // Retry button
  DOM.btnRetry.addEventListener('click', () => {
    if (STATE.currentCity) fetchWeatherByCity(STATE.currentCity);
    else if (STATE.lat && STATE.lon) fetchWeatherByCoords(STATE.lat, STATE.lon);
    else detectUserLocation();
  });

  // History Clear All
  DOM.btnClearHistory.addEventListener('click', clearSearchHistory);
  
  // Favorites toggle in Current weather card
  DOM.btnFav.addEventListener('click', toggleFavoriteCurrent);
  
  // Voice search
  DOM.btnVoice.addEventListener('click', startVoiceSearch);
  
  // Share & PDF download
  DOM.btnShare.addEventListener('click', shareWeather);
  DOM.btnPdf.addEventListener('click', downloadPDFReport);
}

// ─── SEARCH & AUTOCOMPLETE ───
function setUnits(units) {
  if (STATE.units === units) return;
  STATE.units = units;
  localStorage.setItem('wv_units', units);
  
  DOM.btnCelsius.classList.toggle('active', units === 'metric');
  DOM.btnFahrenheit.classList.toggle('active', units === 'imperial');
  
  if (STATE.weather) {
    // If we have cached weather, convert units and redraw
    // (OpenWeatherMap units metric = C, imperial = F)
    // We re-render UI using cached responses (converting values if in demo or re-requesting if live)
    if (STATE.isDemo) {
      renderWeatherData(STATE.weather, STATE.forecast, STATE.aqi);
    } else {
      // Re-fetch to guarantee accurate API conversions
      if (STATE.currentCity) fetchWeatherByCity(STATE.currentCity);
      else if (STATE.lat && STATE.lon) fetchWeatherByCoords(STATE.lat, STATE.lon);
    }
  }
}

function handleSearchInput() {
  const query = DOM.searchInput.value.trim();
  DOM.btnClearSearch.classList.toggle('hidden', query === '');
  
  if (query.length < 2) {
    DOM.autocompleteList.classList.add('hidden');
    return;
  }
  
  if (STATE.isDemo) {
    // Filter popular cities locally
    const filtered = POPULAR_CITIES.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
    showAutocompleteSuggestions(filtered);
  } else {
    // Call Geocoding API – supports cities, towns, villages, districts
    fetch(`https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(query)}&limit=8&appid=${API_KEY}`)
      .then(res => res.json())
      .then(data => {
        if (!Array.isArray(data) || data.length === 0) {
          DOM.autocompleteList.classList.add('hidden');
          return;
        }
        const mapped = data.map(item => ({
          name: item.local_names?.en || item.name,
          country: item.country,
          lat: item.lat,
          lon: item.lon,
          state: item.state
        }));
        showAutocompleteSuggestions(mapped);
      })
      .catch(() => {
        // Fallback to local filtering on error/no-internet
        const filtered = POPULAR_CITIES.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
        showAutocompleteSuggestions(filtered);
      });
  }
}

function showAutocompleteSuggestions(cities) {
  if (cities.length === 0) {
    DOM.autocompleteList.classList.add('hidden');
    return;
  }
  
  DOM.autocompleteList.innerHTML = '';
  cities.forEach(city => {
    const li = document.createElement('li');
    li.role = 'option';
    const stateStr = city.state ? `, ${city.state}` : '';
    li.textContent = `${city.name}${stateStr} (${city.country})`;
    li.addEventListener('click', () => {
      DOM.searchInput.value = city.name;
      DOM.autocompleteList.classList.add('hidden');
      DOM.btnClearSearch.classList.remove('hidden');
      fetchWeatherByCoords(city.lat, city.lon, city.name);
    });
    DOM.autocompleteList.appendChild(li);
  });
  DOM.autocompleteList.classList.remove('hidden');
}

function clearSearchInput() {
  DOM.searchInput.value = '';
  DOM.btnClearSearch.classList.add('hidden');
  DOM.autocompleteList.classList.add('hidden');
  DOM.searchInput.focus();
}

function performSearch() {
  const query = DOM.searchInput.value.trim();
  if (!query) {
    showToast('Please enter a city, town, or village name', 'warning');
    return;
  }
  DOM.autocompleteList.classList.add('hidden');
  DOM.historyPanel.classList.add('hidden');
  
  if (STATE.isDemo) {
    fetchWeatherByCity(query);
  } else {
    // Use geocoding API first so villages and small towns are found reliably
    fetchWeatherByGeocode(query);
  }
}

// Geocoding-first search: finds any village/town/city then fetches weather by coords
async function fetchWeatherByGeocode(query) {
  if (!navigator.onLine) {
    showErrorState('No Internet Connection', 'Please check your internet connection and try again.');
    return;
  }
  showLoading(true);
  try {
    const geoRes = await fetch(
      `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(query)}&limit=1&appid=${API_KEY}`
    );
    const geoData = await geoRes.json();

    if (!Array.isArray(geoData) || geoData.length === 0) {
      showLoading(false);
      showErrorState(
        'Place Not Found',
        `We couldn't find "${query}". Try adding a country code, e.g. "${query}, IN"`
      );
      return;
    }

    const place = geoData[0];
    const displayName = place.local_names?.en || place.name;
    const { lat, lon } = place;

    // Now fetch weather by coordinates
    await fetchWeatherByCoords(lat, lon, displayName);
  } catch (err) {
    console.error(err);
    showLoading(false);
    showErrorState('Request Failed', 'Unable to search for that location. Please try again.');
  }
}

// ─── VOICE SEARCH ───
function startVoiceSearch() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showToast('Voice search is not supported in this browser.', 'warning');
    return;
  }
  
  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  
  DOM.btnVoice.classList.add('listening');
  showToast('Listening for city name...', 'info');
  
  recognition.start();
  
  recognition.onresult = (event) => {
    const city = event.results[0][0].transcript;
    DOM.searchInput.value = city;
    DOM.btnClearSearch.classList.remove('hidden');
    showToast(`Voice Search: "${city}"`, 'success');
    performSearch();
  };
  
  recognition.onerror = (event) => {
    console.error('Speech recognition error', event.error);
    showToast('Could not hear city name. Try speaking again.', 'error');
    DOM.btnVoice.classList.remove('listening');
  };
  
  recognition.onend = () => {
    DOM.btnVoice.classList.remove('listening');
  };
}

// ─── GEOLOCATION ───
function detectUserLocation() {
  if (!navigator.geolocation) {
    showToast('Geolocation is not supported by your browser.', 'warning');
    return;
  }
  
  showLoading(true);
  showToast('Detecting your location…', 'info');
  navigator.geolocation.getCurrentPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;
      STATE.lat = lat;
      STATE.lon = lon;
      fetchWeatherByCoords(lat, lon);
    },
    (error) => {
      showLoading(false);
      let msg = 'Failed to get your location.';
      if (error.code === error.PERMISSION_DENIED) {
        msg = 'Location permission was denied. Please allow location access in your browser settings.';
      } else if (error.code === error.POSITION_UNAVAILABLE) {
        msg = 'Location information is unavailable. Please search manually.';
      } else if (error.code === error.TIMEOUT) {
        msg = 'Location request timed out. Please try again or search manually.';
      }
      showToast(msg, 'warning');
      
      // If we don't have current weather showing, show empty state instead of error
      if (DOM.dashboard.classList.contains('hidden')) {
        showEmptyState();
      }
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
  );
}

function refreshWeather() {
  if (STATE.currentCity) {
    showToast(`Refreshing weather for ${STATE.currentCity}...`, 'info');
    fetchWeatherByCity(STATE.currentCity);
  } else if (STATE.lat && STATE.lon) {
    showToast('Refreshing location weather...', 'info');
    fetchWeatherByCoords(STATE.lat, STATE.lon);
  } else {
    showToast('No active weather details to refresh.', 'warning');
  }
}

// ─── API DATA FETCHING ───
function showLoading(isLoading) {
  if (isLoading) {
    DOM.loadingOverlay.classList.remove('hidden');
  } else {
    DOM.loadingOverlay.classList.add('hidden');
  }
}

function showEmptyState() {
  DOM.emptyState.classList.remove('hidden');
  DOM.dashboard.classList.add('hidden');
  DOM.errorState.classList.add('hidden');
}

function showErrorState(title, message) {
  DOM.errorTitle.textContent = title;
  DOM.errorMsg.textContent = message;
  DOM.errorState.classList.remove('hidden');
  DOM.dashboard.classList.add('hidden');
  DOM.emptyState.classList.add('hidden');
}

function hideAllStates() {
  DOM.emptyState.classList.add('hidden');
  DOM.errorState.classList.add('hidden');
  DOM.dashboard.classList.remove('hidden');
}

async function fetchWeatherByCity(city) {
  if (!navigator.onLine) {
    showErrorState('No Internet Connection', 'Please check your internet connection and try again.');
    return;
  }
  
  showLoading(true);
  
  if (STATE.isDemo) {
    // Simulate API fetch delay
    setTimeout(() => {
      const mock = getMockWeatherData(city);
      if (mock.cod === 404) {
        showLoading(false);
        showErrorState('City Not Found', `We couldn't find "${city}". Please try another search.`);
        return;
      }
      STATE.currentCity = mock.weather.name;
      STATE.lat = mock.weather.coord.lat;
      STATE.lon = mock.weather.coord.lon;
      
      STATE.weather = mock.weather;
      STATE.forecast = mock.forecast;
      STATE.aqi = mock.aqi;
      
      renderWeatherData(mock.weather, mock.forecast, mock.aqi);
      addToHistory(mock.weather.name, mock.weather.sys.country, mock.weather.coord.lat, mock.weather.coord.lon);
      showLoading(false);
      hideAllStates();
    }, 600);
    return;
  }

  // Live Mode API Requests
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=${STATE.units}&appid=${API_KEY}`;
    const res = await fetch(url);
    const weatherData = await res.json();
    
    if (weatherData.cod !== 200) {
      showLoading(false);
      showErrorState(
        weatherData.cod === 404 ? 'City Not Found' : 'API Failure', 
        weatherData.message || 'Something went wrong.'
      );
      return;
    }

    const { lat, lon } = weatherData.coord;
    STATE.currentCity = weatherData.name;
    STATE.lat = lat;
    STATE.lon = lon;
    
    // Parallel fetch forecast & AQI
    const [forecastRes, aqiRes] = await Promise.all([
      fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=${STATE.units}&appid=${API_KEY}`),
      fetch(`https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`)
    ]);
    
    const forecastData = await forecastRes.json();
    const aqiData = await aqiRes.json();
    
    STATE.weather = weatherData;
    STATE.forecast = forecastData;
    STATE.aqi = aqiData;
    
    renderWeatherData(weatherData, forecastData, aqiData);
    addToHistory(weatherData.name, weatherData.sys.country, lat, lon);
    
    hideAllStates();
  } catch (err) {
    console.error(err);
    showErrorState('Request Failed', 'Unable to fetch weather data. Please check your API key or connection.');
  } finally {
    showLoading(false);
  }
}

async function fetchWeatherByCoords(lat, lon, cityName = '') {
  if (!navigator.onLine) {
    showErrorState('No Internet Connection', 'Please check your internet connection and try again.');
    return;
  }
  
  showLoading(true);
  
  if (STATE.isDemo) {
    setTimeout(() => {
      const mock = getMockWeatherData(cityName || `Location (${lat.toFixed(2)}, ${lon.toFixed(2)})`, lat, lon);
      STATE.currentCity = mock.weather.name;
      STATE.lat = lat;
      STATE.lon = lon;
      
      STATE.weather = mock.weather;
      STATE.forecast = mock.forecast;
      STATE.aqi = mock.aqi;
      
      renderWeatherData(mock.weather, mock.forecast, mock.aqi);
      addToHistory(mock.weather.name, mock.weather.sys.country, lat, lon);
      showLoading(false);
      hideAllStates();
    }, 600);
    return;
  }

  try {
    // Fetch current weather, forecast and AQI in parallel
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=${STATE.units}&appid=${API_KEY}`;
    const [res, forecastRes, aqiRes] = await Promise.all([
      fetch(weatherUrl),
      fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=${STATE.units}&appid=${API_KEY}`),
      fetch(`https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`)
    ]);
    
    const weatherData = await res.json();
    const forecastData = await forecastRes.json();
    const aqiData = await aqiRes.json();
    
    if (weatherData.cod !== 200) {
      showLoading(false);
      showErrorState('API Failure', weatherData.message || 'Error retrieving weather data.');
      return;
    }

    // If API returns empty city name (common for villages), use the name from geocoding
    const resolvedName = (weatherData.name && weatherData.name.trim() !== '')
      ? weatherData.name
      : (cityName || `Location (${lat.toFixed(3)}, ${lon.toFixed(3)})`);

    weatherData.name = resolvedName;
    STATE.currentCity = resolvedName;
    STATE.lat = lat;
    STATE.lon = lon;
    
    STATE.weather = weatherData;
    STATE.forecast = forecastData;
    STATE.aqi = aqiData;
    
    renderWeatherData(weatherData, forecastData, aqiData);
    addToHistory(resolvedName, weatherData.sys.country || '', lat, lon);
    
    hideAllStates();
  } catch (err) {
    console.error(err);
    showErrorState('Request Failed', 'Failed to retrieve weather. Please check your API key or connection.');
  } finally {
    showLoading(false);
  }
}

// ─── UI RENDERING ───
function renderWeatherData(weather, forecast, aqi) {
  // Update state properties
  const isCelsius = STATE.units === 'metric';
  const tempUnit = isCelsius ? '°C' : '°F';
  DOM.tempUnitSym.textContent = tempUnit;
  
  // 1. Current Weather Main Block
  DOM.cityName.textContent = weather.name;
  DOM.countryName.textContent = weather.sys.country || '';
  
  // Date time formatting
  const localDate = new Date((Date.now() / 1000 + weather.timezone) * 1000);
  const dateOptions = { weekday: 'long', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC' };
  DOM.datetime.textContent = localDate.toLocaleString('en-US', dateOptions);
  
  // Temp & description
  DOM.currentTemp.textContent = Math.round(weather.main.temp);
  DOM.weatherDesc.textContent = weather.weather[0].description;
  DOM.feelsLike.textContent = `Feels like ${Math.round(weather.main.feels_like)}${tempUnit}`;
  
  // Weather condition background & animated icon
  const condCode = weather.weather[0].id;
  const condMain = weather.weather[0].main.toLowerCase();
  const iconEmoji = getWeatherEmoji(condCode, weather.weather[0].icon);
  DOM.mainIcon.textContent = iconEmoji;
  
  // Determine particle weather animation condition
  let animCondition = 'default';
  if (condCode >= 200 && condCode < 300) animCondition = 'thunder';
  else if ((condCode >= 300 && condCode < 600) || condMain.includes('rain') || condMain.includes('drizzle')) animCondition = 'rain';
  else if (condCode >= 600 && condCode < 700 || condMain.includes('snow')) animCondition = 'snow';
  else if (condCode >= 700 && condCode < 800) animCondition = 'mist';
  else if (condCode === 800) animCondition = weather.weather[0].icon.includes('n') ? 'night' : 'sunny';
  else if (condCode > 800) animCondition = 'clouds';
  
  setWeatherParticles(animCondition);
  
  // Favorite state active check
  const isFav = STATE.favorites.some(fav => fav.name.toLowerCase() === weather.name.toLowerCase());
  DOM.btnFav.classList.toggle('active', isFav);

  // 2. Stats Grid
  DOM.humidity.textContent = `${weather.main.humidity}%`;
  
  const windSpeedUnit = isCelsius ? 'km/h' : 'mph';
  // OpenWeatherMap wind speed is m/s in metric, miles/hour in imperial
  const speed = isCelsius ? Math.round(weather.wind.speed * 3.6) : Math.round(weather.wind.speed);
  DOM.wind.textContent = `${speed} ${windSpeedUnit}`;
  DOM.windDir.textContent = getWindDirection(weather.wind.deg);
  
  DOM.pressure.textContent = `${weather.main.pressure} hPa`;
  
  const visKm = (weather.visibility / 1000).toFixed(1);
  DOM.visibility.textContent = `${visKm} km`;
  
  // Sunset & Sunrise
  DOM.sunrise.textContent = formatUnixTime(weather.sys.sunrise, weather.timezone);
  DOM.sunset.textContent = formatUnixTime(weather.sys.sunset, weather.timezone);
  
  // UV & Air Quality data mapping
  // OWM Free API does not contain UV index in standard current/forecast.
  // We can mock UV realistically or use a dummy safe range based on weather code.
  const mockUV = getRealisticUV(condCode);
  DOM.uv.textContent = mockUV.val;
  DOM.uvBadge.textContent = mockUV.label;
  DOM.uvBadge.className = `badge-pill ${mockUV.class}`;

  // AQI calculations
  if (aqi && aqi.list && aqi.list[0]) {
    const aqiVal = aqi.list[0].main.aqi; // 1 = Good, 2 = Fair, 3 = Moderate, 4 = Poor, 5 = Very Poor
    const aqiMeta = getAQIMetadata(aqiVal);
    DOM.aqi.textContent = aqiVal;
    DOM.aqiBadge.textContent = aqiMeta.label;
    DOM.aqiBadge.className = `badge-pill ${aqiMeta.class}`;
    
    // Draw AQI Gauge
    drawAQIGauge(aqiVal);
    
    // Pollutants List
    renderPollutants(aqi.list[0].components);
  } else {
    DOM.aqi.textContent = '--';
    DOM.aqiBadge.textContent = '--';
    drawAQIGauge(0);
  }
  
  // 3. Hourly Forecast Rendering
  renderHourlyForecast(forecast);

  // 4. 5-Day Forecast Rendering
  render5DayForecast(forecast);
  
  // 5. Alerts section
  renderAlerts(weather, forecast);
}

function renderHourlyForecast(forecast) {
  DOM.hourlyList.innerHTML = '';
  if (!forecast || !forecast.list) return;
  
  const timezoneOffset = forecast.city ? (forecast.city.timezone || 0) : 0;
  
  // Filter next 8 timestamps (24 hours - OWM provides 3-hour steps)
  const items = forecast.list.slice(0, 8);
  items.forEach(item => {
    const localDate = new Date((item.dt + timezoneOffset) * 1000);
    const timeStr = localDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' });
    const temp = Math.round(item.main.temp);
    const emoji = getWeatherEmoji(item.weather[0].id, item.weather[0].icon);
    
    const div = document.createElement('div');
    div.className = 'hourly-item';
    
    // Pop (Probability of precipitation) from OpenWeatherMap (0 to 1)
    const popPct = item.pop ? Math.round(item.pop * 100) : 0;
    const popHtml = popPct > 10 ? `<div class="hourly-pop">💧${popPct}%</div>` : '';
    
    div.innerHTML = `
      <div class="hourly-time">${timeStr}</div>
      <div class="hourly-icon">${emoji}</div>
      <div class="hourly-temp">${temp}°</div>
      ${popHtml}
    `;
    DOM.hourlyList.appendChild(div);
  });
}

function render5DayForecast(forecast) {
  DOM.forecastList.innerHTML = '';
  if (!forecast || !forecast.list) return;
  
  const timezoneOffset = forecast.city ? (forecast.city.timezone || 0) : 0;
  
  // Group list by Day using city-localized dates
  const dailyData = {};
  forecast.list.forEach(item => {
    const localDate = new Date((item.dt + timezoneOffset) * 1000);
    const dateStr = localDate.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
    if (!dailyData[dateStr]) {
      dailyData[dateStr] = [];
    }
    dailyData[dateStr].push(item);
  });
  
  // Convert grouping into 5-day structured layout
  const keys = Object.keys(dailyData).slice(0, 5); // Pick first 5 days
  
  keys.forEach(dateKey => {
    const dayItems = dailyData[dateKey];
    const firstItem = dayItems[0];
    const localDate = new Date((firstItem.dt + timezoneOffset) * 1000);
    const dayName = localDate.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
    
    // Find min and max temp for the day
    let tempMax = -999;
    let tempMin = 999;
    dayItems.forEach(item => {
      if (item.main.temp_max > tempMax) tempMax = item.main.temp_max;
      if (item.main.temp_min < tempMin) tempMin = item.main.temp_min;
    });
    
    const emoji = getWeatherEmoji(firstItem.weather[0].id, firstItem.weather[0].icon);
    const desc = firstItem.weather[0].description;
    
    const itemDiv = document.createElement('div');
    itemDiv.className = 'forecast-item';
    itemDiv.innerHTML = `
      <div class="forecast-day">${dayName}</div>
      <div class="forecast-icon">${emoji}</div>
      <div class="forecast-desc">${desc}</div>
      <div class="forecast-temps">
        <span class="temp-max">${Math.round(tempMax)}°</span>
        <span class="temp-min">${Math.round(tempMin)}°</span>
      </div>
    `;
    DOM.forecastList.appendChild(itemDiv);
  });
}

function renderPollutants(components) {
  DOM.pollutantGrid.innerHTML = '';
  const list = [
    { label: 'PM2.5', val: components.pm2_5, unit: 'µg/m³' },
    { label: 'PM10', val: components.pm10, unit: 'µg/m³' },
    { label: 'NO₂', val: components.no2, unit: 'µg/m³' },
    { label: 'O₃', val: components.o3, unit: 'µg/m³' },
    { label: 'CO', val: (components.co / 1000).toFixed(2), unit: 'mg/m³' },
    { label: 'SO₂', val: components.so2, unit: 'µg/m³' }
  ];
  
  list.forEach(p => {
    const item = document.createElement('div');
    item.className = 'pollutant-item';
    item.innerHTML = `
      <div class="pollutant-name">${p.label}</div>
      <div class="pollutant-value">${p.val}</div>
      <div class="s-sub">${p.unit}</div>
    `;
    DOM.pollutantGrid.appendChild(item);
  });
}

function renderAlerts(weather, forecast) {
  DOM.alertsCard.classList.add('hidden');
  DOM.alertsList.innerHTML = '';
  
  // OpenWeatherMap free tier does not return severe alerts in standard calls.
  // We will generate contextual notifications based on weather states to show simulated warnings.
  const alerts = [];
  
  // Humidity/Heat Alert
  if (weather.main.temp > 35 && STATE.units === 'metric' || weather.main.temp > 95 && STATE.units === 'imperial') {
    alerts.push({
      event: 'Extreme Heat Advisory',
      desc: 'High temperatures expected. Stay hydrated, avoid direct sunlight and check on vulnerable individuals.',
      time: 'Immediate'
    });
  }
  
  // Rain/Storm alert
  const windSpd = weather.wind.speed;
  if (windSpd > 15) { // 15 m/s or high km/h
    alerts.push({
      event: 'High Wind Warning',
      desc: 'Strong gusts can blow loose objects. Caution is advised when traveling outdoors.',
      time: 'Active'
    });
  }
  
  // Heavy rain detection from descriptions
  const rainKeywords = ['heavy rain', 'thunderstorm', 'squall', 'tornado', 'hurricane'];
  const desc = weather.weather[0].description.toLowerCase();
  const hasStormKeyword = rainKeywords.some(keyword => desc.includes(keyword));
  
  if (hasStormKeyword) {
    alerts.push({
      event: 'Severe Weather Warning',
      desc: 'Heavy precipitation or storm active in this sector. Seek shelter and avoid outdoor plans.',
      time: 'Immediate'
    });
  }
  
  if (alerts.length > 0) {
    DOM.alertsCard.classList.remove('hidden');
    alerts.forEach(alert => {
      const div = document.createElement('div');
      div.className = 'alert-item';
      div.innerHTML = `
        <div class="alert-event">${alert.event}</div>
        <div class="alert-desc">${alert.desc}</div>
        <div class="alert-time">${alert.time}</div>
      `;
      DOM.alertsList.appendChild(div);
    });
  }
}

// ─── CANVAS AQI GAUGE RENDERING ───
function drawAQIGauge(aqiIndex) {
  const canvas = DOM.aqiCanvas;
  const ctx = canvas.getContext('2d');
  const cx = canvas.width / 2;
  const cy = canvas.height - 10;
  const r = 60;
  
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // Draw Semi Circle Arc Background
  ctx.beginPath();
  ctx.arc(cx, cy, r, Math.PI, 2 * Math.PI);
  ctx.lineWidth = 12;
  ctx.strokeStyle = STATE.theme === 'dark' ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)';
  ctx.lineCap = 'round';
  ctx.stroke();
  
  if (aqiIndex === 0) return;
  
  // Color code values
  const colors = ['#22c55e', '#eab308', '#f97316', '#ef4444', '#7c3aed'];
  const activeColor = colors[aqiIndex - 1] || '#94a3b8';
  
  // Draw Active Arc Portion
  const totalAngle = Math.PI;
  const portion = (aqiIndex / 5);
  const endAngle = Math.PI + (totalAngle * portion);
  
  ctx.beginPath();
  ctx.arc(cx, cy, r, Math.PI, endAngle);
  ctx.lineWidth = 12;
  ctx.strokeStyle = activeColor;
  ctx.lineCap = 'round';
  ctx.stroke();
  
  // Draw Pointer Needle
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(endAngle);
  
  ctx.beginPath();
  ctx.moveTo(0, -6);
  ctx.lineTo(r - 12, 0);
  ctx.lineTo(0, 6);
  ctx.closePath();
  ctx.fillStyle = STATE.theme === 'dark' ? '#fff' : '#1a1a2e';
  ctx.fill();
  
  // Center Pin
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fillStyle = activeColor;
  ctx.fill();
  
  ctx.restore();
  
  // Label values mapping
  const labels = ['Good', 'Fair', 'Moderate', 'Poor', 'Very Poor'];
  DOM.aqiBig.textContent = aqiIndex;
  DOM.aqiLabel.textContent = labels[aqiIndex - 1] || '--';
}

// ─── FAVORITES MANAGEMENT ───
function toggleFavoriteCurrent() {
  if (!STATE.weather) return;
  
  const cityName = STATE.weather.name;
  const country = STATE.weather.sys.country || '';
  const lat = STATE.weather.coord.lat;
  const lon = STATE.weather.coord.lon;
  
  const existingIdx = STATE.favorites.findIndex(fav => fav.name.toLowerCase() === cityName.toLowerCase());
  
  if (existingIdx > -1) {
    STATE.favorites.splice(existingIdx, 1);
    showToast(`Removed ${cityName} from favorites`, 'info');
  } else {
    STATE.favorites.push({ name: cityName, country, lat, lon });
    showToast(`Added ${cityName} to favorites`, 'success');
  }
  
  localStorage.setItem('wv_favorites', JSON.stringify(STATE.favorites));
  updateFavoritesUI();
  
  // Sync the current star button active class
  DOM.btnFav.classList.toggle('active', existingIdx === -1);
}

function updateFavoritesUI() {
  DOM.favCount.textContent = STATE.favorites.length;
  DOM.favList.innerHTML = '';
  
  if (STATE.favorites.length === 0) {
    DOM.favList.innerHTML = '<p class="empty-msg">No favorites yet. Search a city and tap ☆ to save it.</p>';
    return;
  }
  
  STATE.favorites.forEach(fav => {
    const item = document.createElement('div');
    item.className = 'fav-item';
    
    // Quick load on click
    item.addEventListener('click', (e) => {
      if (e.target.classList.contains('fav-remove')) return;
      DOM.searchInput.value = fav.name;
      DOM.btnClearSearch.classList.remove('hidden');
      fetchWeatherByCoords(fav.lat, fav.lon, fav.name);
    });
    
    item.innerHTML = `
      <div class="fav-city-info">
        <span class="fav-icon">📍</span>
        <div>
          <span class="fav-name">${fav.name}</span>
          <span class="fav-country">${fav.country}</span>
        </div>
      </div>
      <div style="display: flex; align-items: center;">
        <button class="fav-remove" title="Remove Favorite" aria-label="Remove Favorite">✕</button>
      </div>
    `;
    
    // Hook up delete click handler
    item.querySelector('.fav-remove').addEventListener('click', (e) => {
      e.stopPropagation();
      removeFavoriteByName(fav.name);
    });
    
    DOM.favList.appendChild(item);
  });
}

function removeFavoriteByName(name) {
  STATE.favorites = STATE.favorites.filter(fav => fav.name.toLowerCase() !== name.toLowerCase());
  localStorage.setItem('wv_favorites', JSON.stringify(STATE.favorites));
  updateFavoritesUI();
  
  if (STATE.weather && STATE.weather.name.toLowerCase() === name.toLowerCase()) {
    DOM.btnFav.classList.remove('active');
  }
  showToast(`Removed ${name} from favorites`, 'info');
}

// ─── SEARCH HISTORY ───
function addToHistory(name, country, lat, lon) {
  // Remove if duplicate exists
  STATE.history = STATE.history.filter(item => item.name.toLowerCase() !== name.toLowerCase());
  
  // Insert at front
  STATE.history.unshift({ name, country, lat, lon });
  
  // Cap history at 5 items
  if (STATE.history.length > 5) {
    STATE.history.pop();
  }
  
  localStorage.setItem('wv_history', JSON.stringify(STATE.history));
  updateHistoryUI();
}

function updateHistoryUI() {
  DOM.historyList.innerHTML = '';
  if (STATE.history.length === 0) {
    DOM.historyPanel.classList.add('hidden');
    return;
  }
  
  STATE.history.forEach(item => {
    const div = document.createElement('div');
    div.className = 'history-item';
    
    div.addEventListener('click', (e) => {
      if (e.target.classList.contains('history-remove')) return;
      DOM.searchInput.value = item.name;
      DOM.btnClearSearch.classList.remove('hidden');
      DOM.historyPanel.classList.add('hidden');
      fetchWeatherByCoords(item.lat, item.lon, item.name);
    });
    
    div.innerHTML = `
      <div class="history-item-name">
        <span>🕒</span>
        <span>${item.name}, ${item.country}</span>
      </div>
      <button class="history-remove" title="Remove" aria-label="Remove item">✕</button>
    `;
    
    div.querySelector('.history-remove').addEventListener('click', (e) => {
      e.stopPropagation();
      removeHistoryItem(item.name);
    });
    
    DOM.historyList.appendChild(div);
  });
}

function removeHistoryItem(name) {
  STATE.history = STATE.history.filter(item => item.name.toLowerCase() !== name.toLowerCase());
  localStorage.setItem('wv_history', JSON.stringify(STATE.history));
  updateHistoryUI();
  showToast(`Removed ${name} from history`, 'info');
}

function clearSearchHistory() {
  STATE.history = [];
  localStorage.removeItem('wv_history');
  updateHistoryUI();
  showToast('Search history cleared', 'info');
}

// ─── SHARE & EXPORT ───
function shareWeather() {
  if (!STATE.weather) {
    showToast('No weather details loaded yet to share.', 'warning');
    return;
  }
  
  const text = `Current weather in ${STATE.weather.name}, ${STATE.weather.sys.country}: ${Math.round(STATE.weather.main.temp)}${STATE.units === 'metric' ? '°C' : '°F'} and ${STATE.weather.weather[0].description}. Check out WeatherVista!`;
  
  if (navigator.share) {
    navigator.share({
      title: `WeatherVista - ${STATE.weather.name}`,
      text: text,
      url: window.location.href
    })
    .then(() => showToast('Shared successfully!', 'success'))
    .catch((err) => console.log('Error sharing:', err));
  } else {
    // Copy to clipboard fallback
    navigator.clipboard.writeText(text)
      .then(() => showToast('Weather report copied to clipboard!', 'success'))
      .catch(() => showToast('Could not copy report to clipboard.', 'error'));
  }
}

function downloadPDFReport() {
  if (!STATE.weather) {
    showToast('No weather details loaded yet to download.', 'warning');
    return;
  }
  
  // Construct clean styling for printable weather document
  const printWindow = window.open('', '_blank');
  
  const unitsText = STATE.units === 'metric' ? '°C' : '°F';
  const windSpeedUnit = STATE.units === 'metric' ? 'km/h' : 'mph';
  const speed = STATE.units === 'metric' ? Math.round(STATE.weather.wind.speed * 3.6) : Math.round(STATE.weather.wind.speed);
  
  let forecastHtml = '';
  if (STATE.forecast && STATE.forecast.list) {
    // Parse 5 days forecast
    const dailyData = {};
    STATE.forecast.list.forEach(i => {
      const date = new Date(i.dt * 1000).toDateString();
      if (!dailyData[date]) dailyData[date] = i;
    });
    Object.keys(dailyData).slice(0, 5).forEach(dayKey => {
      const item = dailyData[dayKey];
      const dayName = new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'long' });
      forecastHtml += `
        <tr style="border-bottom: 1px solid #ddd;">
          <td style="padding: 10px; font-weight: bold;">${dayName}</td>
          <td style="padding: 10px; text-transform: capitalize;">${item.weather[0].description}</td>
          <td style="padding: 10px; text-align: right; color: #f97316;">${Math.round(item.main.temp_max)}°</td>
          <td style="padding: 10px; text-align: right; color: #60a5fa;">${Math.round(item.main.temp_min)}°</td>
        </tr>
      `;
    });
  }

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>WeatherVista Report - ${STATE.weather.name}</title>
      <style>
        body { font-family: 'Outfit', 'Helvetica Neue', Arial, sans-serif; color: #1a1a2e; padding: 40px; line-height: 1.5; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #667eea; padding-bottom: 20px; }
        .title { font-size: 28px; font-weight: bold; margin: 0; color: #302b63; }
        .date { font-size: 14px; color: #666; }
        .main-weather { display: flex; align-items: center; justify-content: space-between; margin-top: 30px; background: #f7f9fc; border-radius: 12px; padding: 24px; }
        .temp { font-size: 64px; font-weight: 800; color: #302b63; }
        .desc { font-size: 20px; font-weight: bold; text-transform: capitalize; color: #666; }
        .stats-table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        .stats-table td { padding: 12px; border-bottom: 1px solid #eee; }
        .stats-label { font-weight: bold; color: #555; }
        .stats-val { text-align: right; font-weight: bold; color: #1a1a2e; }
        .section-title { font-size: 20px; font-weight: bold; color: #302b63; margin-top: 40px; border-bottom: 1px solid #667eea; padding-bottom: 8px; }
        .forecast-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .footer { text-align: center; font-size: 12px; color: #999; margin-top: 60px; border-top: 1px solid #eee; padding-top: 20px; }
      </style>
    </head>
    <body>
      <div class="header">
        <div>
          <h1 class="title">WeatherVista Dashboard Report</h1>
          <span class="date">${new Date().toLocaleString()}</span>
        </div>
        <div style="font-size: 24px; font-weight: bold; color: #667eea;">🌐 WeatherVista</div>
      </div>
      
      <div class="main-weather">
        <div>
          <div style="font-size: 32px; font-weight: bold;">${STATE.weather.name}, ${STATE.weather.sys.country}</div>
          <div class="desc">${STATE.weather.weather[0].description}</div>
          <div style="font-size: 14px; color: #888; margin-top: 6px;">Feels like: ${Math.round(STATE.weather.main.feels_like)}${unitsText}</div>
        </div>
        <div class="temp">${Math.round(STATE.weather.main.temp)}${unitsText}</div>
      </div>
      
      <table class="stats-table">
        <tr>
          <td class="stats-label">💧 Humidity</td><td class="stats-val">${STATE.weather.main.humidity}%</td>
          <td class="stats-label">🌬️ Wind Speed</td><td class="stats-val">${speed} ${windSpeedUnit}</td>
        </tr>
        <tr>
          <td class="stats-label">🧭 Pressure</td><td class="stats-val">${STATE.weather.main.pressure} hPa</td>
          <td class="stats-label">👁️ Visibility</td><td class="stats-val">${(STATE.weather.visibility / 1000).toFixed(1)} km</td>
        </tr>
        <tr>
          <td class="stats-label">🌅 Sunrise</td><td class="stats-val">${formatUnixTime(STATE.weather.sys.sunrise, STATE.timezone)}</td>
          <td class="stats-label">🌇 Sunset</td><td class="stats-val">${formatUnixTime(STATE.weather.sys.sunset, STATE.timezone)}</td>
        </tr>
      </table>
      
      <div class="section-title">5-Day Forecast</div>
      <table class="forecast-table">
        <thead>
          <tr style="background: #f7f9fc; text-align: left;">
            <th style="padding: 10px;">Day</th>
            <th style="padding: 10px;">Condition</th>
            <th style="padding: 10px; text-align: right;">Max Temp</th>
            <th style="padding: 10px; text-align: right;">Min Temp</th>
          </tr>
        </thead>
        <tbody>
          ${forecastHtml}
        </tbody>
      </table>
      
      <div class="footer">
        Generated by WeatherVista weather application. Powered by OpenWeatherMap API.
      </div>
      <script>
        window.onload = function() {
          window.print();
          window.onafterprint = function() { window.close(); };
        };
      </script>
    </body>
    </html>
  `;
  
  printWindow.document.write(htmlContent);
  printWindow.document.close();
  showToast('Printing weather report PDF...', 'success');
}

// ─── UTILITIES & HELPERS ───
function formatUnixTime(unixStamp, timezoneOffset = 0) {
  // Convert Unix timestamp to localized string matching coordinates timezone
  const localDate = new Date((unixStamp + timezoneOffset) * 1000);
  return localDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' });
}

function getWindDirection(deg) {
  if (deg === undefined) return '--';
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const index = Math.round(deg / 45) % 8;
  return directions[index];
}

function getRealisticUV(code) {
  // Mocking UV index index levels logically based on weather codes
  if (code === 800) return { val: 6.8, label: 'High', class: 'unhealthy' }; // Sunny
  if (code > 800 && code < 803) return { val: 4.2, label: 'Moderate', class: 'moderate' }; // Mild Clouds
  if (code >= 803) return { val: 2.1, label: 'Low', class: 'good' }; // Overcast
  if (code >= 200 && code < 700) return { val: 1.0, label: 'Low', class: 'good' }; // Raining/Storm
  return { val: 3.5, label: 'Moderate', class: 'moderate' };
}

function getAQIMetadata(aqi) {
  const meta = [
    { label: 'Good', class: 'good' },
    { label: 'Fair', class: 'moderate' },
    { label: 'Moderate', class: 'moderate' },
    { label: 'Poor', class: 'unhealthy' },
    { label: 'Very Poor', class: 'hazardous' }
  ];
  return meta[aqi - 1] || { label: 'Unknown', class: 'good' };
}

function getWeatherEmoji(code, iconCode = '') {
  // Return attractive high-resolution emoji icons
  const isNight = iconCode.includes('n');
  if (code >= 200 && code < 300) return '⛈️'; // Thunderstorm
  if (code >= 300 && code < 400) return '🌦️'; // Drizzle
  if (code >= 500 && code < 600) {
    if (code === 500 || code === 501) return '🌧️';
    return '🌧️'; // Heavy Rain
  }
  if (code >= 600 && code < 700) return '❄️'; // Snow
  if (code >= 700 && code < 800) return '🌫️'; // Atmosphere (Mist/Fog/Dust)
  if (code === 800) return isNight ? '🌙' : '☀️'; // Clear Sky
  if (code === 801) return isNight ? '☁️' : '🌤️'; // Few clouds
  if (code === 802) return '⛅'; // Scattered clouds
  if (code >= 803) return '☁️'; // Overcast clouds
  return '🌡️';
}

// ─── HIGH-FIDELITY MOCK DATA GENERATOR (For Demo / Ready-to-Run out-of-the-box experience) ───
function getMockWeatherData(cityName, lat, lon) {
  // Normalize name
  const formattedCityName = cityName.trim().split(',')[0];
  
  // Simple check for valid popular city search to make coordinates match, or use default random coords
  const matchedCity = POPULAR_CITIES.find(c => c.name.toLowerCase() === formattedCityName.toLowerCase());
  
  const latitude = lat || (matchedCity ? matchedCity.lat : (Math.random() * 80 - 40));
  const longitude = lon || (matchedCity ? matchedCity.lon : (Math.random() * 240 - 120));
  const country = matchedCity ? matchedCity.country : 'US';
  
  // Custom mock values based on city name or random seed to feel dynamic
  const seed = formattedCityName.length || 7;
  const isCelsius = STATE.units === 'metric';
  const baseTemp = 15 + (seed % 15) + (isCelsius ? 0 : 32); // 15C - 30C or corresponding F
  
  // Create mock current weather
  const weather = {
    coord: { lat: latitude, lon: longitude },
    weather: [{ id: 800 + (seed % 4), main: seed % 2 === 0 ? 'Clouds' : 'Clear', description: seed % 2 === 0 ? 'scattered clouds' : 'clear sky', icon: '01d' }],
    base: 'stations',
    main: {
      temp: baseTemp,
      feels_like: baseTemp + 1,
      temp_min: baseTemp - 3,
      temp_max: baseTemp + 4,
      pressure: 1012,
      humidity: 50 + (seed % 35),
      sea_level: 1012,
      grnd_level: 1009
    },
    visibility: 10000,
    wind: { speed: 3.5 + (seed % 8), deg: 120 + (seed * 10) },
    clouds: { all: 20 },
    dt: Math.round(Date.now() / 1000),
    sys: { type: 1, id: 1234, country: country, sunrise: Math.round((Date.now() - 20000000) / 1000), sunset: Math.round((Date.now() + 20000000) / 1000) },
    timezone: 19800,
    id: 1277333,
    name: formattedCityName,
    cod: 200
  };

  // Mock 5-day / 3-hour Forecast
  const forecastList = [];
  const startTs = Math.round(Date.now() / 1000);
  
  for (let i = 0; i < 40; i++) {
    const stepTs = startTs + (i * 3 * 3600); // 3-hour increments
    const stepTemp = baseTemp + Math.sin(i / 2) * 5 + (Math.random() * 2 - 1);
    
    forecastList.push({
      dt: stepTs,
      main: {
        temp: stepTemp,
        feels_like: stepTemp + 0.5,
        temp_min: stepTemp - 1,
        temp_max: stepTemp + 1.5,
        pressure: 1012,
        humidity: 50 + (seed % 30)
      },
      weather: [{
        id: 800 + ((seed + i) % 5),
        main: (seed + i) % 3 === 0 ? 'Clear' : 'Clouds',
        description: (seed + i) % 3 === 0 ? 'clear sky' : 'broken clouds',
        icon: '02d'
      }],
      wind: { speed: 2 + ((seed + i) % 5) },
      pop: Math.max(0, Math.sin(i / 3) * 0.8),
      dt_txt: new Date(stepTs * 1000).toISOString()
    });
  }

  const forecast = {
    cod: '200',
    message: 0,
    cnt: 40,
    list: forecastList,
    city: {
      id: 1277333,
      name: formattedCityName,
      coord: { lat: latitude, lon: longitude },
      country: country,
      population: 100000,
      timezone: 19800
    }
  };

  // Mock AQI Response
  const aqi = {
    coord: { lat: latitude, lon: longitude },
    list: [{
      main: { aqi: 1 + (seed % 5) }, // 1 to 5
      components: {
        co: 200 + (seed * 30),
        no: 0.1,
        no2: 2.5 + (seed * 2),
        o3: 35 + (seed * 5),
        so2: 1.1 + (seed),
        pm2_5: 5.5 + (seed * 4),
        pm10: 12 + (seed * 6),
        nh3: 0.2
      },
      dt: Math.round(Date.now() / 1000)
    }]
  };

  return { cod: 200, weather, forecast, aqi };
}
