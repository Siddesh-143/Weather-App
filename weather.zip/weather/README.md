# WeatherVista 🌐

WeatherVista is a complete, modern, responsive Weather Dashboard Web Application built from scratch using HTML5, CSS3 (Vanilla Glassmorphism), and pure ES6+ JavaScript. It integrates with the OpenWeatherMap API to deliver real-time weather analytics, 5-day forecasts, hourly trends, air quality statistics, severe weather alerts, and more.

Out-of-the-box, the app includes a high-fidelity **Demo/Mock Mode** that makes it fully functional and testable immediately, without requiring an API key. Once a valid OpenWeatherMap API key is provided, it seamlessly switches to live data fetches.

---

## ✨ Features

- **Glassmorphism UI**: Beautiful, premium frosted glass interface designed for visual comfort.
- **Dynamic Backgrounds & Particles**: A custom HTML5 Canvas particle system that morphs based on the weather conditions (e.g. rain drops for stormy weather, soft drifts for snow, floating amber particles for sunny conditions, and twinkling stars at night).
- **Current Location (Geolocation)**: Auto-detects user coordinates to load local conditions instantly.
- **Search History**: Local Storage-backed search history panel allowing quick toggle and retrieval.
- **Favorite Cities**: Save, track, and remove favorites. Click favorite items to quickly load their current conditions.
- **Hourly Forecast**: Scrollable horizontal hourly cards covering the next 24 hours.
- **5-Day Forecast**: Weekly trend cards displaying daily high/low temperatures and conditions.
- **Air Quality index (AQI)**: A custom-drawn semi-circle gauge rendering particle matter (PM2.5, PM10, CO, NO₂, O₃, SO₂) and severity rating.
- **Theme and Unit Toggle**: Dark/Light mode toggle and Celsius (°C) / Fahrenheit (°F) temperature scales.
- **Voice Search**: Integrates Web Speech API to allow searching by spoken city names.
- **Autocomplete Suggestions**: Quick search suggestions based on major world cities or direct Geocoding API responses.
- **Share & PDF Export**: Quickly copy a formatted weather status card to the clipboard (or trigger Web Share API on mobile), and download a beautifully styled PDF report of the active city.
- **Robust Error Handling**: Handle offline connections, empty inputs, and invalid city queries gracefully with structured error recovery states.

---

## 🛠️ Technologies Used

- **Frontend**: HTML5 (Semantic Markup), CSS3 (Custom Variables, Flexbox/Grid, Keyframe Animations, Glassmorphic effects), JavaScript (ES6+ Modules, Fetch API, Canvas 2D API).
- **APIs**: [OpenWeatherMap API](https://openweathermap.org/) (Current Weather Data, 5-Day / 3-Hour Forecast, Air Pollution).
- **Storage**: Local Storage API.
- **Device Support**: Fully responsive across mobile, tablet, and ultra-wide desktop views.

---

## 📂 Folder Structure

```text
WeatherVista/
│
├── index.html       # Application entry page with HTML5 dashboard layout
├── style.css        # Responsive glassmorphism styles, dark/light theme systems
├── script.js        # Core controller logic, particle canvas system, API operations
└── README.md        # Documentation and guide
```

---

## 🚀 Installation & Setup Steps

1. **Clone or Download the Repository**:
   ```bash
   git clone https://github.com/your-username/WeatherVista.git
   cd WeatherVista
   ```

2. **Run the Project via Terminal**:
   You can serve the project locally using any of the following command-line tools:

   * **Option A: Python (Built-in)**
     ```bash
     python -m http.server 8000
     ```
     Once started, navigate to `http://localhost:8000` in your web browser.

   * **Option B: Node.js (npx)**
     ```bash
     npx http-server -p 8000
     ```
     Once started, navigate to `http://localhost:8000` in your web browser.

   * **Option C: Open Directly (No server)**
     * *Windows (Command Prompt / PowerShell)*:
       ```bash
       start index.html
       ```
     * *macOS*:
       ```bash
       open index.html
       ```
     * *Linux*:
       ```bash
       xdg-open index.html
       ```

3. **Configure API Key (Optional but Recommended for Live Data)**:
   - Go to [OpenWeatherMap](https://openweathermap.org/) and sign up for a free account.
   - Create and copy your **API Key** from the developer dashboard.
   - Open `script.js` in your editor.
   - Replace `'YOUR_API_KEY'` at the top of `script.js` with your active API key:
     ```javascript
     const API_KEY = 'your_actual_openweathermap_api_key_here';
     ```
   - Save the file and reload the web page. The application will immediately begin fetching live meteorological data.

---

## 🔮 Future Enhancements

- **Interactive Weather Map**: Integrate Leaflet.js or OpenWeatherMap layers to visualize precipitation, wind currents, and temperature changes dynamically on an interactive map widget.
- **Expanded Air Quality Analytics**: Detailed historical graphs for pollutant indexes using Chart.js.
- **Push Alerts**: Enable background browser worker notifications for sudden severe weather warnings in favorite cities.

---

## 👤 Author

- **Senior Full-Stack Developer & UI/UX Designer**
- Portfolio & GitHub: [Your Portfolio Link / GitHub Username]
